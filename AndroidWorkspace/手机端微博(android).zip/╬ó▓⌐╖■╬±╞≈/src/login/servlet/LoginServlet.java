package login.servlet;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.corba.se.impl.orbutil.ObjectWriter;

public class LoginServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("userName");
		String password = request.getParameter("password");
		String message = null;
		if("mary".equals(name) && "1234".equals(password)){
			System.out.println("��¼�ɹ�");
			message = "hello";
		}
		else{
			System.out.println("��¼ʧ��");
			message = "byebye";
		}
		response.setContentType("text/html");
		response.setCharacterEncoding("utf-8");
		
		////////////////////////////////////////////
		User u = new User();
		u.setName("mary");
		u.setPassword("1234");
		u.setId(1);
		OutputStream out = response.getOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(out);
		oos.writeObject(u);
		
		///////////////////////////////////////////
		out.flush();
		out.close();
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
