package com.cn;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserDBO {

	Database dbo;
	Context context;
	
	UserDBO(Context context) {
		// TODO Auto-generated constructor stub
		this.context = context;
		dbo = new Database(context, "weibo", null, 1);
	}
	
	public void addUser(User u){
		SQLiteDatabase db = dbo.getWritableDatabase();
		
		ContentValues cv = new ContentValues();
		cv.put("id", 0);
		cv.put("name", u.getName());
		cv.put("password", u.getPassword());
		db.insert("user", null, cv);
	}	//�����û�
	
	public boolean denglu(String user_name, String pass){
		String sql = "select * from user where name='" + user_name + "' and password='" + pass +"'";
		SQLiteDatabase db = dbo.getWritableDatabase();
		Cursor cursor = db.rawQuery(sql, null);
		while(cursor.moveToNext()){
//			int num = cursor.getShort(0);
			String name = cursor.getString(1);
			String password = cursor.getString(2);
			if (name.equals(user_name) && password.equals(pass)){
				return true;
			}
		}
		return false;		
	}//��¼
	
	public boolean seekUser(String user_name) {
		// TODO Auto-generated method stub
		String sql = "select * from user where name='" + user_name + "'";
		SQLiteDatabase db = dbo.getWritableDatabase();
		Cursor cursor = db.rawQuery(sql, null);
		while(cursor.moveToNext()){
//			int num = cursor.getShort(0);
			String name = cursor.getString(1);
			if (name.equals(user_name)){
				return true;
			}
		}
		return false;		
	}//��ѯ�����Ƿ��Ѿ����ڴ��û���
}
