package com.cn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MyRegistActivity extends Activity {

	EditText nameT;
	EditText pass1T;
	EditText pass2T;
	Button backT;
	
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.regist);
		
		nameT = (EditText)this.findViewById(R.id.nameR);
		pass1T = (EditText)this.findViewById(R.id.pass1);
		pass2T = (EditText)this.findViewById(R.id.pass2);
		backT = (Button)this.findViewById(R.id.buttonR);
		
		backT.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String name = nameT.getText().toString(); 
				String pass1 = pass1T.getText().toString();
				String pass2 = pass2T.getText().toString();
				UserDBO dbo = new UserDBO(MyRegistActivity.this);
				if(!pass1.equals(pass2)){
					pass2T.setText("");
					return;
				}
				
				boolean bool = dbo.seekUser(name);
				if(bool){
					nameT.setText("");
					pass1T.setText("");
					pass2T.setText("");
					return;
				}
				
				User u = new User();
				u.setName(name);
				u.setPassword(pass1);
				dbo.addUser(u);
				Intent in = new Intent(MyRegistActivity.this, MyWeiBoActivity.class);
				MyRegistActivity.this.startActivity(in);
			}
		});//ע��ɹ������ص�¼����
	}
}
