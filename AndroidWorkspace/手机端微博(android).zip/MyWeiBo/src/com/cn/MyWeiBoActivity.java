package com.cn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MyWeiBoActivity extends Activity {
    /** Called when the activity is first created. */
	
	EditText nameD;
	EditText passD;
	Button buttonD;
	Button buttonZ;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        nameD = (EditText)this.findViewById(R.id.nameD);
        passD = (EditText)this.findViewById(R.id.passD);
        buttonD = (Button)this.findViewById(R.id.buttonD);
        buttonZ = (Button)this.findViewById(R.id.buttonZ);
        
        buttonD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String user_name = nameD.getText().toString();
				String pass = passD.getText().toString();
				boolean bool = new UserDBO(MyWeiBoActivity.this).denglu(user_name, pass);
				if(bool){
					Intent in = new Intent(MyWeiBoActivity.this, MyView.class);
					MyWeiBoActivity.this.startActivity(in);
				}
				else{
					nameD.setText("");
					passD.setText("");
				}
			}
		});//��¼
        
        buttonZ.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in = new Intent(MyWeiBoActivity.this, MyRegistActivity.class);
				MyWeiBoActivity.this.startActivity(in);
			}
		});//��ת��ע�����
        
        
    }
}