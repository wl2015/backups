package a.b.c;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import login.servlet.User;

import org.apache.http.HttpConnection;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class ABCActivity extends Activity {
    /** Called when the activity is first created. */
	
	EditText nameT;
	EditText passT;
	Button loginB;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        nameT = (EditText)this.findViewById(R.id.name);
        passT = (EditText)this.findViewById(R.id.pass);
        loginB = (Button)this.findViewById(R.id.login);
        loginB.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				String name = nameT.getText().toString();
				String password = passT.getText().toString();
				
				
				String urlStr = "http://192.168.0.123:8080/abc/login?userName=" + name + "&password=" + password;
				try{
				URL url = new URL(urlStr);
				//�ö����ܰ�Android������web�����������������ӣ���ͨ���ö�������web������
				HttpURLConnection conn = (HttpURLConnection)url.openConnection();
				
				//�ȵ����صĻ�Ӧ��Ϣ
				if(conn.getResponseCode() == HttpURLConnection.HTTP_OK){
					InputStream in = conn.getInputStream();
					//////////////////////////////////////////////
					ObjectInputStream ois = new ObjectInputStream(in);
					User u = (User)ois.readObject();
					System.out.println(u.getName());
					System.out.println(u.getPassword());
					System.out.println(u.getId());
					///////////////////////////////////////
					in.close();
				}
				conn.disconnect();
				System.out.println("����"); 
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
    }
    
    
}