package com.test;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MyHandlerActivity extends Activity {
    /** Called when the activity is first created. */
	TextView tv = null;
	Button b = null;
	Handler handler = new Handler();
	int i = 0;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv = (TextView)this.findViewById(R.id.tv);
        b = (Button)this.findViewById(R.id.b);
        b.setOnClickListener(new MyClickListener());
    }
    
    class MyClickListener implements OnClickListener{
    	@Override
    	public void onClick(View arg0) {
    		handler.removeCallbacks(run);
    		handler.post(run);
    	}
    }
    
    Runnable run = new Runnable() {
		@Override
		public void run() {
			tv.append(String.valueOf(i++));
			handler.postDelayed(run, 100);
			
		}
	};
}