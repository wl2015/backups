package com.android;

import android.app.Activity;
import android.os.Bundle;

public class MyActivity2 extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.main2);
	}

}
