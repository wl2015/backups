package com.cn;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;


import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MyPhoneBookActivity extends Activity {
    /** Called when the activity is first created. */
	Button b;
    @SuppressWarnings("unchecked")
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        b = (Button)this.findViewById(R.id.add);       
        SharedPreferences sp = this.getSharedPreferences("users", Activity.MODE_WORLD_READABLE);
        LinearLayout userList = (LinearLayout)this.findViewById(R.id.userList);
        Map userMap = sp.getAll();
        Set<String> keySet = userMap.keySet();
        Iterator<String> keyIt = keySet.iterator();
        
        while(keyIt.hasNext()){
        	String name = keyIt.next();
        	TextView tv = new TextView(this);
        	tv.setOnTouchListener(new MyTouch());
        	tv.setText(name);
        	userList.addView(tv);
        }
        
        b.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in = new Intent(MyPhoneBookActivity.this, Addfriends.class);
				MyPhoneBookActivity.this.startActivity(in);
			}
		});
    }
    
    class MyTouch implements OnTouchListener{

		@Override
		public boolean onTouch(View v, MotionEvent me) {
			// TODO Auto-generated method stub
			TextView nowTv = (TextView)v;
    		String name = nowTv.getText().toString();
    		SharedPreferences sp = MyPhoneBookActivity.this.getSharedPreferences("users", Activity.MODE_WORLD_READABLE);
    		String num = sp.getString(name, "");
    		if(me.getAction() == MotionEvent.ACTION_UP){
    			Intent in = new Intent();
    			in.setAction(Intent.ACTION_CALL);
    			Uri uri = Uri.parse("tel:" + num);
    			in.setData(uri);
    			MyPhoneBookActivity.this.startActivity(in);
    		}
    		return true;
		}
    	
    }
}