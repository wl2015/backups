package com.cn;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Addfriends extends Activity {
	
	EditText nameb;
	EditText numb;
	Button bc;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addfriends);
		
		nameb = (EditText)this.findViewById(R.id.name);
		numb = (EditText)this.findViewById(R.id.num);
		bc = (Button)this.findViewById(R.id.back);
		
		bc.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String name = nameb.getText().toString();
				String num = numb.getText().toString();
				SharedPreferences.Editor editor = Addfriends.this.getSharedPreferences("users", Activity.MODE_WORLD_WRITEABLE).edit();
				editor.putString(name, num);
				editor.commit();
				
				Intent in = new Intent(Addfriends.this, MyPhoneBookActivity.class);
				Addfriends.this.startActivity(in);
			}
		});
	}
}
