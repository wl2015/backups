package test.pk;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserDBO {
	Database dbo;
	Context context;
	
	public UserDBO(Context context) {
		// TODO Auto-generated constructor stub
		this.context = context;
		dbo = new Database(context, "weibo", null, 1);
	}
	
	public void addUser(User u){
		SQLiteDatabase db = dbo.getWritableDatabase();
		
		ContentValues cv = new ContentValues();
		cv.put("id", 0);
		cv.put("name", u.getName());
		cv.put("num", u.getNum());
		cv.put("address", u.getAddress());
		db.insert("user", null, cv);
	}//�����û�
	
	public boolean check(String user_num) {
		// TODO Auto-generated method stub
		String sql = "select * from user where num='" + user_num + "'";
		SQLiteDatabase db = dbo.getWritableDatabase();
		Cursor cursor = db.rawQuery(sql, null);
		while(cursor.moveToNext()){
			String num = cursor.getString(2);
			if (num.equals(user_num)){
				return true;
			}
		}
		return false;	
	}//�绰�����Ѵ�
	
	public User outShow(int user_id) {
		// TODO Auto-generated method stub
		User u = new User();
		String sql = "select * from user where id='" + user_id + "'";
		SQLiteDatabase db = dbo.getWritableDatabase();
		Cursor cursor = db.rawQuery(sql, null);
		while(cursor.moveToNext()){
			String name = cursor.getString(1);
			String num = cursor.getString(2);
			String address = cursor.getString(3);
			u.setName(name);
			u.setNum(num);
			u.setAddress(address);
		}
		return u;	
	}
}
