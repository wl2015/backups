package test.pk;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class AddFriendsActivity extends Activity {

	boolean bool;
	EditText nameT;
	EditText numT;
	EditText addressT;
	Button back;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addfriends);
		
		nameT = (EditText)this.findViewById(R.id.name);
		numT = (EditText)this.findViewById(R.id.num);
		addressT = (EditText)this.findViewById(R.id.adress);
		back = (Button)this.findViewById(R.id.back);
		
		back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String  name = nameT.getText().toString();
				String num = numT.getText().toString();
				String address = addressT.getText().toString();
				UserDBO dbo = new UserDBO(AddFriendsActivity.this);
				bool = dbo.check(num);
				if(bool){
					nameT.setText("");
					numT.setText("");
					addressT.setText("");
					return;
				}
				
				User u = new User();
				u.setName(name);
				u.setNum(num);
				u.setAddress(address);
				dbo.addUser(u);
				
				Intent in = new Intent(AddFriendsActivity.this, NewPhoneBookActivity.class);
				AddFriendsActivity.this.startActivity(in);
			}
		});
	}
}
