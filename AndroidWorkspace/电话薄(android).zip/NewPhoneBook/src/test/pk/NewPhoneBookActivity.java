package test.pk;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NewPhoneBookActivity extends Activity {
    /** Called when the activity is first created. */
	boolean bool;
	Button add;
	int user_id= 0;
	User u = new User();
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        add = (Button)this.findViewById(R.id.add);
        
        LinearLayout userList = (LinearLayout)this.findViewById(R.id.userList);
        UserDBO dbo = new UserDBO(NewPhoneBookActivity.this);
        
        while(bool){
        	u = (User)dbo.outShow(user_id);
        	user_id++;
        	String name = u.getName();
        	if(name.equals(null)){
        		bool = false;
        		return;
        	}
        	else{
	        	TextView tv = new TextView(this);
	        	tv.setText(name);
	        	userList.addView(tv);
        	}
        }
        
        add.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent in = new Intent(NewPhoneBookActivity.this, AddFriendsActivity.class);
				NewPhoneBookActivity.this.startActivity(in);
			}
		});//��ת�����ӽ���
    }
}