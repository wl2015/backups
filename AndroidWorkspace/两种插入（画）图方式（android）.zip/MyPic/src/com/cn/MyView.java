package com.cn;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class MyView extends View {
	public MyView(Context context, AttributeSet attributeSet){
		super(context,attributeSet);
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		Bitmap bitmap = BitmapFactory.decodeResource(this.getResources(), R.drawable.img);
		Paint paint = new Paint();
		canvas.drawBitmap(bitmap, 0, 0, paint);
		super.onDraw(canvas);
	}
}
