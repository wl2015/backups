package com.cn;

import android.app.Activity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MyAnimationActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        ImageView im = (ImageView)this.findViewById(R.id.ig);
        Animation ma = AnimationUtils.loadAnimation(this, R.anim.myanima);
        im.startAnimation(ma);
    }
}