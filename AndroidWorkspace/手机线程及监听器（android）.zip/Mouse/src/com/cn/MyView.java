package com.cn;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class MyView extends View {
	public MyView(Context context){
		super(context);
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);
		
		canvas.drawColor(Color.WHITE);
		
		Paint paint = new Paint();
		paint.setStyle(Paint.Style.STROKE);
		paint.setAntiAlias(true);
		paint.setColor(Color.RED);
		paint.setStrokeWidth(2);
		canvas.drawCircle(40, 30, 20, paint);
		canvas.drawRect(20, 70, 70, 120, paint);
		canvas.drawRect(20, 170, 90, 130, paint);
		RectF re = new RectF(20, 230, 100,190);
		canvas.drawOval(re, paint);

	}
}
