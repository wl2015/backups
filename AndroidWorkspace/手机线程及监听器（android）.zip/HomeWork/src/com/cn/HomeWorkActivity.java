package com.cn;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class HomeWorkActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        final Animation out = AnimationUtils.loadAnimation(this, R.anim.myout);
        final Animation back = AnimationUtils.loadAnimation(this, R.anim.myback);
        final ImageView im = (ImageView)this.findViewById(R.id.ig2);
        ImageView myout = (ImageView)this.findViewById(R.id.ig3);
        ImageView myback = (ImageView)this.findViewById(R.id.ig4);


        
        myout.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
		        im.startAnimation(out);
			}
		});
        
        myback.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
		        im.startAnimation(back);
			}
		});
        
    }
}