package com.cn;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.view.View;

public class MyView extends View {
	int x = 0, y = 40;
	
	Handler h = new Handler();
	public MyView(Context context) {
		super(context);
		h.post(new BoxMove());
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		
		canvas.drawColor(Color.GRAY);//������ɫ
		
		Paint paint = new Paint();
		paint.setColor(Color.RED);
		canvas.drawRect(x, y, x+40, y+40, paint);
		super.onDraw(canvas);
	}
	
	class BoxMove implements Runnable{
		
		@Override
		public void run() {
			if(x+40>320){
				x=0;
			}
			else{
				x++;
			}
			MyView.this.invalidate();//�ػ���������
			h.postDelayed(this, 50);
		}
	}

}
