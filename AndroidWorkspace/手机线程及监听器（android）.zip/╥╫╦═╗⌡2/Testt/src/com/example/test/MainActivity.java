package com.example.test;

import android.os.Bundle;
import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;

public class MainActivity extends Activity {
	
	ImageView iv2;
	ImageButton ib1;
	ImageButton ib2;
	
	int newHeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView iv1 = (ImageView)this.findViewById(R.id.img1);
        iv1.setImageResource(R.drawable.t1);
        
         iv2 = (ImageView)this.findViewById(R.id.img2);
        DisplayMetrics dm = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = iv2.getBackground().getIntrinsicWidth();
        
        
        
        newHeight = dm.heightPixels*width/dm.widthPixels;
        if(newHeight > dm.heightPixels/3){
        	newHeight = dm.heightPixels/3;
        }
        
        
        
        iv2.setMinimumHeight(newHeight);
        
       
        
        
        
         ib1 = (ImageButton)this.findViewById(R.id.button1);
        ib1.setImageResource(R.drawable.t3);
        ib1.setOnClickListener(new Button1Listener());
        
         ib2 = (ImageButton)this.findViewById(R.id.button2);
        ib2.setImageResource(R.drawable.t4);
        ib2.setOnClickListener(new Button2Listener());
        
    }
    
    class Button1Listener implements OnClickListener{
    	@Override
    	public void onClick(View v) {
    		 AnimationSet as = new AnimationSet(true);
    		 as.setInterpolator(new LinearInterpolator());
    	        TranslateAnimation ta = new TranslateAnimation(
    	        		Animation.RELATIVE_TO_SELF, 0, 
    	        		Animation.RELATIVE_TO_SELF,0,
    	        		Animation.RELATIVE_TO_SELF,0,
    	        		Animation.RELATIVE_TO_SELF,-1
    	        		);
    	        AlphaAnimation aa = new AlphaAnimation(1, 0);
    	        
    	        as.addAnimation(aa);
    	        as.addAnimation(ta);
    	        as.setDuration(1000);
    	        as.setFillAfter(true);
    	        iv2.startAnimation(as);
    	}
    }
    
    class Button2Listener implements OnClickListener{
    	@Override
    	public void onClick(View v) {
    		AnimationSet as = new AnimationSet(true);
   		 as.setInterpolator(new LinearInterpolator());
   	        TranslateAnimation ta = new TranslateAnimation(
   	        		Animation.RELATIVE_TO_SELF, 0, 
   	        		Animation.RELATIVE_TO_SELF,0,
   	        		Animation.RELATIVE_TO_SELF,-1,
   	        		Animation.RELATIVE_TO_SELF,0
   	        		);
   	        AlphaAnimation aa = new AlphaAnimation(0, 1);
   	        
   	        as.addAnimation(aa);
   	        as.addAnimation(ta);
   	        as.setDuration(1000);
   	        as.setFillAfter(true);
   	        iv2.startAnimation(as);
    	}
    }
    
    
    
}
