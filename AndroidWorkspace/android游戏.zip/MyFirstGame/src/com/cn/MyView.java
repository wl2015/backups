package com.cn;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class MyView extends View {
	int point_x=-1,point_y=-1;//��ʼλ��
	
	int[][] maps={
			{2,5,6,2,4,8},
			{6,4,8,5,2,2},
			{5,6,3,2,6,3},
			{6,5,2,3,3,6},
			{2,4,8,1,2,4},
			{4,2,8,2,4,1}};//���ӱ��������

	public MyView(Context context, AttributeSet as){
		super(context, as);
	}
	
	public MyView(Context context) {
		super(context);
		this.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent e) {
				// TODO Auto-generated method stub
				int col = (int)e.getX()/50;
				int row = (int)e.getY()/50;
				System.out.println("bbbbb");
				if (point_x != -1){
					if(maps[point_x][point_y] == maps[row][col] && (point_x != row || point_y != col)){
						maps[point_x][point_y] = 0;
						maps[row][col] = 0;
						point_x = -1;
						point_y = -1;
					}
					else{
						point_x = row;
						point_y = col;
					}
					//
				}//�ж����������Ƿ����
				else{
					point_x = row;
					point_y = col;
				}
				MyView.this.invalidate();//�ػ���������
				return false;
			}
		});//���Ӽ�����
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		
		Bitmap bitmap = BitmapFactory.decodeResource(this.getResources(), R.drawable.img);
		Paint paint = new Paint();
		for(int i = 0; i < 6; i++){
			for(int j = 0; j < 6; j++){
				canvas.drawBitmap(bitmap, i*50, j*50, paint);
			}
		}//������
		
		for(int i = 0; i < 6; i++){
			for(int j = 0; j < 6; j++){
				if(maps[i][j]==0){
					canvas.drawRect(j*50, i*50, j*50+50, i*50+50, paint);
				}
			}
		}//������
		if(point_x != -1){
			paint.setColor(Color.WHITE);
			paint.setTextSize(50);
			canvas.drawText(maps[point_x][point_y]+"", point_y*50+10, point_x*50+30, paint);
		}//��ʾ���һ�ε���Ǹ����ӱ��������
		super.onDraw(canvas);
	}
}
