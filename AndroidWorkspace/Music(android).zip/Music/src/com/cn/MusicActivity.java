package com.cn;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;

public class MusicActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        MediaPlayer mp = MediaPlayer.create(this, R.raw.a);
        mp.start();
    }
}